# 导入模块
import yaml

# 配置常量
config: dict = {}


# 读取配置文件
def read_config() -> None:
    global config
    with open('../config/config.yml', encoding='utf-8') as cfg:
        data = yaml.load(cfg, Loader=yaml.FullLoader)  # 读取yaml文件
        config = data


# 配置经验值
async def ConfigExp(xp: int) -> dict:
    all_xp: dict = config['exp']
    exp_str: str = 'level-'
    ret_dict: dict = {}
    for i in range(1, len(all_xp)):
        l_exp = all_xp[exp_str + f'{i - 1}']
        r_exp = all_xp[exp_str + f'{i}']
        l_level = i - 1
        r_level = i
        if l_exp < xp <= r_exp:
            ret_dict['exp'] = xp
            ret_dict['level'] = r_level
        elif xp == l_exp:
            ret_dict['exp'] = xp
            ret_dict['level'] = l_level
    if ret_dict == {}:
        return {"exp": "Error", "level": "Error"}
    else:
        return ret_dict


# 获取该条消息的所有信息
async def KookUserApiShort(msg) -> dict:
    user_name = msg.author.username
    kook_number = msg.author.id
    identity_group = (await msg.ctx.guild.fetch_user(kook_number)).roles
    send_server_id = msg.ctx.guild.id
    user_avatar = msg.author.avatar
    return {"user": user_name, "number": kook_number,
            "identity_group": identity_group, "server_id": send_server_id,
            "user_avatar": user_avatar}
