from khl import *

import DataManipulation as dm

print('开始运行')
# 读取配置文件
dm.read_config()
# 导入常量
dm_config: dict = dm.config  # 读取数据
bot: Bot = Bot(token=dm_config['bot_information']['token'])  # 创建bot
bot_command: dict = dm_config['command']  # 注册指令


@bot.command(name=bot_command['QF']['register_command'])
async def QF(msg: Message):
    inf = await dm.KookUserApiShort(msg)
    msg_json = [
        {
            "type": "card",
            "theme": "secondary",
            "size": "lg",
            "color": "#4169E1",
            "modules": [
                {
                    "type": "header",
                    "text": {
                        "type": "plain-text",
                        "content": "QWind社区"
                    }
                },
                {
                    "type": "divider"
                },
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "image",
                            "src": f"{inf['user_avatar']}"
                        },
                        {
                            "type": "plain-text",
                            "content": f"{inf['user']}"
                        }
                    ]
                },
                {
                    "type": "section",
                    "text": {
                        "type": "paragraph",
                        "cols": 3,
                        "fields": [
                            {
                                "type": "kmarkdown",
                                "content": f"**积分**\n10"
                            },
                            {
                                "type": "kmarkdown",
                                "content": f"**等级**\n1"
                            },
                            {
                                "type": "kmarkdown",
                                "content": f"**经验值**\n114"
                            }
                        ]
                    }
                },
                {
                    "type": "divider"
                },
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "plain-text",
                            "content": "功能区"
                        }
                    ]
                },
                {
                    "type": "action-group",
                    "elements": [
                        {
                            "type": "button",
                            "theme": "info",
                            "value": "签到",
                            "click": "return-val",
                            "text": {
                                "type": "plain-text",
                                "content": "签到"
                            }
                        },
                        {
                            "type": "button",
                            "theme": "info",
                            "value": "商城",
                            "click": "return-val",
                            "text": {
                                "type": "plain-text",
                                "content": "商城"
                            }
                        },
                        {
                            "type": "button",
                            "theme": "info",
                            "value": "http://www.mhc233.top/",
                            "click": "link",
                            "text": {
                                "type": "plain-text",
                                "content": "前往官网"
                            }
                        },
                        {
                            "type": "button",
                            "theme": "info",
                            "value": "https://kook.top/aDiEHc",
                            "click": "link",
                            "text": {
                                "type": "plain-text",
                                "content": "问题反馈 | 产品建议"
                            }
                        }
                    ]
                },
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "plain-text",
                            "content": "-由清云工作室强力支持"
                        }
                    ]
                }
            ]
        }
    ]
    await msg.ctx.channel.send(msg_json, type=MessageTypes.CARD, temp_target_id=inf['number'])


# bot run
bot.run()
