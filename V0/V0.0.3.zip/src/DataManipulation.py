# 导入模块
import yaml
from khl import MessageTypes, api

# 配置常量
config: dict = {}


# 读取配置文件
def read_config() -> None:
    global config
    with open('../config/config.yml', encoding='utf-8') as cfg:
        data = yaml.load(cfg, Loader=yaml.FullLoader)  # 读取yaml文件
        config = data


# 配置经验值
async def ConfigExp(xp: int) -> dict:
    all_xp: dict = config['exp']
    exp_str: str = 'level-'
    ret_dict: dict = {}
    for i in range(1, len(all_xp)):
        l_exp = all_xp[exp_str + f'{i - 1}']
        r_exp = all_xp[exp_str + f'{i}']
        l_level = i - 1
        r_level = i
        if l_exp < xp <= r_exp:
            ret_dict['exp'] = xp
            ret_dict['level'] = r_level
        elif xp == l_exp:
            ret_dict['exp'] = xp
            ret_dict['level'] = l_level
    if ret_dict == {}:
        return {"exp": "Error", "level": "Error"}
    else:
        return ret_dict


# 获取该条消息的所有信息
async def KookUserApiShort(msg) -> dict:
    user_name = msg.author.username
    kook_number = msg.author.id
    identity_group = (await msg.ctx.guild.fetch_user(kook_number)).roles
    send_server_id = msg.ctx.guild.id
    send_channel_id = msg.ctx.channel.id
    user_avatar = msg.author.avatar
    return {"user": user_name, "number": kook_number,
            "identity_group": identity_group, "server_id": send_server_id,
            "user_avatar": user_avatar, "channel_id": send_channel_id}


# 输出
async def ToSay(msg, bot, text, project: str, temporary: bool, numbers: int = 0) -> None:
    if project == 'text':
        if temporary:
            await msg.ctx.channel.send(text, temp_target_id=numbers)
        else:
            await msg.ctx.channel.send(text)
    elif project == 'card':
        if temporary:
            await msg.ctx.channel.send(text, type=MessageTypes.CARD, temp_target_id=numbers)
        else:
            await msg.ctx.channel.send(text, type=MessageTypes.CARD)
    elif project == 'text-to':
        say = await bot.fetch_public_channel(numbers)
        await say.send(text)
    elif project == 'card-to':
        say = await bot.fetch_public_channel(numbers)
        await say.send(text, type=MessageTypes.CARD)


# 分析获取指令
async def TurnCommandHelp(number: int, command_dict: dict) -> list:
    all_list: list = []
    for pointer in command_dict:
        all_list.append(command_dict[pointer])
    start: int = number * 5 - 5
    end: int = number * 5
    lang: int = len(all_list)
    end_list: list = []
    if lang < end:
        for pointer_low in range(start, lang):
            end_list.append(all_list[pointer_low])
    else:
        for pointer_more in range(start, end):
            end_list.append(all_list[pointer_more])
    return end_list


# 简化指令
async def ReducedInstruction(number: int, command_dict: dict) -> list:
    get_list_command = await TurnCommandHelp(number, command_dict)
    return_list: list = []
    for pointer in get_list_command:
        return_list.append([pointer['name'], pointer['parameter'], pointer['context']])
    return return_list


# 将命令转化为字符串
async def ToString(number: int, command_dict: dict) -> str:
    get_list_command = await ReducedInstruction(number, command_dict)
    end_string: str = ""
    for pointer in get_list_command:
        end_string += f"> **{pointer[2]}**\n`{pointer[0]} {pointer[1]}`\n"
    return end_string


# 获取指定频道所有消息并删除
async def DeleteAllMessage(bot, target_id: str) -> None:
    data_get_msg: dict = {'target_id': target_id}
    while True:
        try:
            msgs_list: list = []
            getter = await bot.client.gate.request('POST', 'message/list', data=data_get_msg)
            for pointer in getter['items']:
                msgs_list.append(pointer['id'])
            for all_msg_pointer in msgs_list:
                await bot.client.gate.request('POST', 'message/delete', data={"msg_id": all_msg_pointer})
        except:
            break


# 全服喊话系列
async def SayToServer(bot, no_register: dict, msg, text: str) -> None:
    inf = await KookUserApiShort(msg)
    information_list: list = []
    information_list_dict: list = []
    channels = await bot.client.gate.exec_req(
        api.Channel.list(guild_id=inf['server_id']))
    var: list = channels['items']
    dict_for_say_server = [
        {
            "type": "card",
            "theme": "secondary",
            "size": "lg",
            "color": "#4169E1",
            "modules": [
                {
                    "type": "header",
                    "text": {
                        "type": "plain-text",
                        "content": "全服喊话"
                    }
                },
                {
                    "type": "section",
                    "text": {
                        "type": "kmarkdown",
                        "content": f">   {inf['user']}  发送了全服喊话"
                    },
                    "mode": "left",
                    "accessory": {
                        "type": "image",
                        "src": f"{inf['user_avatar']}",
                        "size": "lg"
                    }
                },
                {
                    "type": "divider"
                },
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "plain-text",
                            "content": "喊话内容"
                        }
                    ]
                },
                {
                    "type": "section",
                    "text": {
                        "type": "kmarkdown",
                        "content": f"**{text}**"
                    }
                },
                {
                    "type": "divider"
                },
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "kmarkdown",
                            "content": f"发送者频道(chn){inf['channel_id']}(chn)"
                        }
                    ]
                }
            ]
        }
    ]
    for pointer in range(len(var)):
        if var[pointer]['is_category']:
            pass
        else:
            information_list.append(var[pointer])
    for choose in information_list:
        information_list_dict.append({'name': choose['name'], 'id': choose['id']})
    for to_saying in information_list_dict:
        if to_saying in no_register:
            pass
        else:
            await ToSay(msg, bot, dict_for_say_server, 'card-to', True, numbers=to_saying['id'])


# 判断频道是否为组队大厅
async def IfZuDui(msg) -> bool:
    inf = await KookUserApiShort(msg)
    channel_id = config['channel_id']
    if inf['channel_id'] == channel_id:
        return True
    else:
        return False
